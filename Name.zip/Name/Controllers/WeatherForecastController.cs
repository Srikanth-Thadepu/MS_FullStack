using Microsoft.AspNetCore.Mvc;

namespace Name.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FirstNameLastNameController : ControllerBase
    {
        [HttpGet("submit")]
        public IActionResult GetFullName([FromQuery] string firstName, [FromQuery] string lastName)
        {
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
            {
                return BadRequest("Both first and last names are required.");
            }

            string fullName = $"{firstName} {lastName}";
            return Ok(new { Message = $"Hello, {fullName}!" });
        }

        [HttpGet("GetStudent")]
        public Student GetStudent(int rollno, string name)
        {
            Student student = new Student();
            student.Name = name;
            student.Id = rollno;
            return student;
        }
    }

    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
