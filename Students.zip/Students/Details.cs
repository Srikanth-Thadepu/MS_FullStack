﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class  Student
    {
        public string Name;
        public int Id;

        public Student(string name,int id)
        {
            Name = name;
            Id = id;
        }

        public virtual void Print()
        {
            Console.WriteLine($"Student Name: {Name}, ID: {Id}");
        }
    }
}
