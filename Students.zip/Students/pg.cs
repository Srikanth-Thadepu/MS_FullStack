﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class pg : Student
    {
        public string ResearchTopic;

        public pg(string name, int id, string researchTopic) : base(name, id)
        {
            ResearchTopic = researchTopic;
        }
        public override void Print()
        {
            Console.WriteLine($" PG Student Name: {Name}, ID: {Id}, Research Topic: {ResearchTopic}");
        }
    }
}
