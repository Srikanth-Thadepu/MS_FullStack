﻿using System;
using Students;

namespace MainProgram
{
    class Program
    {
        static void Main()
        {
            Student ug = new Ug("Alice", 101, "Computer Science");
            Student pg = new Pg("Bob", 202, "AI and Machine Learning");

            ug.Print();
            pg.Print();
        }
    }
    public class Student
    {
        public string Name;
        public int Id;
        public virtual void Print()
        {
            Console.WriteLine($"Name: {Name}, ID: {Id}");
        }
    }
    public class Ug : Student
    {
        public string Major;

        public Ug(string name, int id, string major)
        {
            Name = name;
            Id = id;
            Major = major;
        }

        public override void Print()
        {
            base.Print();
            Console.WriteLine($"Major: {Major}");
        }
    }
    public class Pg : Student
    {
        public string Specialization;

        public Pg(string name, int id, string specialization)
        {
            Name = name;
            Id = id;
            Specialization = specialization;
        }

        public override void Print()
        {
            base.Print();
            Console.WriteLine($"Specialization: {Specialization}");
        }
    }
}
