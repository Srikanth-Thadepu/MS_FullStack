﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Students
{
    public class Ug : Student
    {
        public string Major;

        public Ug(string name, int id, string major) : base(name, id)
        {
            Major = major;
        }
        public override void Print()
        {
            Console.WriteLine($" UG Student Name: {Name}, ID: {Id}, Major: {Major}");
        }
    }
}
