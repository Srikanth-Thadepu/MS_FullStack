﻿namespace WebApplication4
{
    using Microsoft.EntityFrameworkCore;
    using WebApplication4.Model;

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Student> Students { get; set; }
    }

}
