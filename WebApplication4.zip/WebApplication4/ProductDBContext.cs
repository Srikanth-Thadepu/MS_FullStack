﻿namespace WebApplication4
{
    using Microsoft.EntityFrameworkCore;
    using WebApplication4.Model;

    public class ProductDBContext : DbContext
    {
        public ProductDBContext(DbContextOptions<ProductDBContext> options) : base(options) { }
        public DbSet<Product> Products { get; set; }
        public object Product { get; internal set; }
    }
}