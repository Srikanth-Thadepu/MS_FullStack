﻿namespace WebApplication4.Model
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductBrand { get; set; }
        public string ProductName { get; set; }
    }
}
