﻿namespace FirstWebApi.Controllers
{
    public class Student
    {
        public object Name { get; internal set; }
        public object Id { get; internal set; }
    }
}