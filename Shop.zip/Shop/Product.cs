﻿namespace Shop
{
    public class Product
    {
    }
}
