﻿using System;

public class Student
{
    public string Name { get; set; }
    public int Id { get; set; }
    public int Age { get; set; }

    public void Display()
    {
        Console.WriteLine("Name: {0}, Id: {1}, Age: {2}", Name, Id, Age);
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        Student student = new Student
        {
            Name = "John Doe",
            Id = 123,
            Age = 20
        };

        student.Display();
    }
}