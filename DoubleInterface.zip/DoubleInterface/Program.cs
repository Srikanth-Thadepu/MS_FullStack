﻿using System;

namespace InterfaceExample
{
    // First interface with one method
    public interface IFirstInterface
    {
        void MethodA();
        void CommonMethod();
    }

    // Second interface with one method
    public interface ISecondInterface
    {
        void MethodB();
        void CommonMethod();
    }

    // Class implementing both interfaces
    public class ImplementingClass : IFirstInterface, ISecondInterface
    {
        // Implementing MethodA from IFirstInterface
        public void MethodA()
        {
            Console.WriteLine("MethodA from IFirstInterface");
        }

        // Implementing MethodB from ISecondInterface
        public void MethodB()
        {
            Console.WriteLine("MethodB from ISecondInterface");
        }

        // Implementing CommonMethod from both interfaces
        void IFirstInterface.CommonMethod()
        {
            Console.WriteLine("CommonMethod from IFirstInterface");
        }

        void ISecondInterface.CommonMethod()
        {
            Console.WriteLine("CommonMethod from ISecondInterface");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ImplementingClass obj = new ImplementingClass();

            // Calling MethodA
            obj.MethodA();

            // Calling MethodB
            obj.MethodB();

            // Calling CommonMethod from IFirstInterface
            ((IFirstInterface)obj).CommonMethod();

            // Calling CommonMethod from ISecondInterface
            ((ISecondInterface)obj).CommonMethod();
        }
    }
}