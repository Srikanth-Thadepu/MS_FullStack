﻿namespace Testing
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
        public int Add(int a, int b, int c)
        {
            return a + b + c;
        }
    }
}
