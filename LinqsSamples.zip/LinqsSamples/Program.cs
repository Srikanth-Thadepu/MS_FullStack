﻿namespace LinqsSamples
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<UGStudent> students = new List<UGStudent>();
            List<int> studentIds = new List<int>();

            students.Add(new UGStudent() { Name = "Anu", RollNo = 1 });
            students.Add(new UGStudent() { Name = "Bhanu", RollNo = 2 });
            students.Add(new UGStudent() { Name = "Chinnu", RollNo = 3 });
            students.Add(new UGStudent() { Name = "Dinnu", RollNo = 4 });
            students.Add(new UGStudent() { Name = "Ennuu", RollNo = 5 });
            students.Add(new UGStudent() { Name = "Fannu", RollNo = 6 });

            var FilterNames = from student in students
                              where student.RollNo > 3
                              orderby student.RollNo ascending
                              select student.Name;

            foreach (var name in FilterNames)
            {
                Console.WriteLine(name);
            }
        }
    }
    public class UGStudent
    {
        public string Name { get; set; }
        public int RollNo { get; set; }
    }
}
