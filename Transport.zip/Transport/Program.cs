﻿namespace Transport
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person man = new Person("John", Gender.Male);
            Person woman = new Person("Jane", Gender.Female);

            man.DisplayModeOfTransport();
            woman.DisplayModeOfTransport();
        }
    }
}
