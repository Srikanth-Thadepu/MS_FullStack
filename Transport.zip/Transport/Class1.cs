﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// File: Person.cs
namespace Transport
{
    public enum Gender
    {
        Male,
        Female
    }

    public class Person
    {
        public string Name { get; set; }
        public Gender Gender { get; set; }

        public Person(string name, Gender gender)
        {
            Name = name;
            Gender = gender;
        }

        public void DisplayModeOfTransport()
        {
            string modeOfTransport = Gender switch
            {
                Gender.Male => "Bike or Walk",
                Gender.Female => "Bus",
                _ => "Unknown"
            };

            Console.WriteLine($"{Name} uses {modeOfTransport}.");
        }
    }
}