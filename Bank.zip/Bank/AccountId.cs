﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    public class AccountId
    {
        private string accountId;

        public string AccountId
        { 
            get
            {
                return "lkadb" + accountId + "lzsjbdvlj";
            } 

            set {
                if AccountId.Length == 10
                {
                    accountId = value;
                }
                else
                {
                    Console.WriteLine("Invalid account ID");
                }
            }
    }
}
