﻿namespace Bank
{
    public class Program
    {
        private static void Main(string[] args)
        {
            BankAccount account = new BankAccount(1234567890);
            Console.WriteLine(account.AccountId);
        }
    }
}
